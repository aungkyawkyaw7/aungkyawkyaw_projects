from django.shortcuts import render, redirect, HttpResponseRedirect
from .models import Member
# Create your views here.

def index(request):
    if request.method == 'POST':
        member = Member(firstname=request.POST['firstname'], lastname=request.POST['lastname'],  email=request.POST['email'], password=request.POST['password'])
        member.save()
        return redirect('/')
    else:
        return render(request, 'web/index.html')

def login(request):
    return render(request, 'web/login.html')

def home(request):
    if request.method == 'POST':
        if Member.objects.filter(firstname=request.POST['firstname'], lastname=request.POST['lastname']).exists():
            member = Member.objects.get(firstname=request.POST['firstname'], lastname=request.POST['lastname'])
            return render(request, 'web/home.html', {'member': member})
        else:
            context = {'msg': 'Invalid firstname or lastname'}
            return render(request, 'web/login.html', context)




           