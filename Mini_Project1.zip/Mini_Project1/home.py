#! C:\Python36\python.exe
import cgi
import cgitb;cgitb.enable()

print("Content-type:text/html\n\n")

print("""
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: #006882;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 98%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: 	#F0F8FF;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}


h1 {
  color: black;
  text-align: center;
}



/* Set a style for the submit button */
.registerbtn {
  background-color: #004d2a;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

</style>
</head>
<body>

<form name='testform' action="register.py" method="post">
  <div class="container">
    <h1>Register</h1>
    <hr>
	<label for="firstname"><b>Firstname</b></label>
    <input type="text" placeholder="Enter Firtname" name="firstname" required>
	
	<label for="lastname"><b>Lastname</b></label>
    <input type="text" placeholder="Enter Lastname" name="lastname" required>
	
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

    <input type="hidden" name="submitted" value="1">
    <button type="submit" class="registerbtn">Register</button>
  </div>
</form>
</body>
</html>

""")
