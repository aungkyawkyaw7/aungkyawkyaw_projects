#! C:/Python36/python
import MySQLdb
import cgi
import cgitb;  
cgitb.enable()  #to track cgi error
print("Content-type: text/html\n\n")
db =MySQLdb.connect(host="localhost", port=3306, user="root", password="1234", db="pythondemo")
cursor = db.cursor()
form=cgi.FieldStorage()
def getFieldValue(fieldname):
    if fieldname in form:
        return form[fieldname].value
if "submitted" in form:
    firstname=getFieldValue("firstname")
    lastname=getFieldValue("lastname")
    email=getFieldValue("email")
    password=getFieldValue("psw")
    
    try:
        cursor.execute("insert into employee (firstname,lastname,email,password) values('{0}','{1}','{2}','{3}')".format(firstname, lastname,email,password))
        print(firstname,  lastname, email,password,'successfully inserted')
        db.commit()
    except:
        print("Error occured")
        db.rollback()
db.close    
